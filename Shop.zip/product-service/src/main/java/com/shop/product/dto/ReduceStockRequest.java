package com.shop.product.dto;

import jakarta.validation.constraints.Min;

public record ReduceStockRequest(@Min(1) Integer quantity) {}
