# Shop 微服务示例

这是一个 Maven 多模块 Spring Boot 项目，不使用 Spring Cloud 和 OpenFeign。

## 模块

| 服务 | 端口 | 数据库 |
|---|---:|---|
| user-service | 8081 | shop_user |
| product-service | 8082 | shop_product |
| order-service | 8083 | shop_order |
| invoice-service | 8084 | shop_invoice |

## 技术

- Java 21
- Spring Boot 4.1.0
- Spring Web
- Spring Data JPA
- MySQL
- RestClient
- BCrypt

## 启动前准备

在 MySQL 中执行：

```sql
CREATE DATABASE shop_user CHARACTER SET utf8mb4;
CREATE DATABASE shop_product CHARACTER SET utf8mb4;
CREATE DATABASE shop_order CHARACTER SET utf8mb4;
CREATE DATABASE shop_invoice CHARACTER SET utf8mb4;
```

默认数据库账号：

```text
username=root
password=123456
```

请根据本机配置修改各模块的 `application.properties`。

## 编译

在 Shop 根目录执行：

```bash
mvn clean package
```

## 启动顺序

1. user-service
2. product-service
3. invoice-service
4. order-service

## 示例流程

### 1. 注册用户

```http
POST http://localhost:8081/users/register
Content-Type: application/json

{
  "username": "tom",
  "password": "123456",
  "fullName": "Tom Smith"
}
```

### 2. 登录

```http
POST http://localhost:8081/users/login
Content-Type: application/json

{
  "username": "tom",
  "password": "123456"
}
```

### 3. 添加商品

```http
POST http://localhost:8082/products
Content-Type: application/json

{
  "name": "Laptop",
  "price": 4999.00,
  "stock": 10
}
```

### 4. 创建订单

```http
POST http://localhost:8083/orders
Content-Type: application/json
X-User-Id: 1

{
  "items": [
    {
      "productId": 1,
      "quantity": 2
    }
  ]
}
```

订单服务会：

1. 调用 product-service 查询商品并扣减库存；
2. 保存订单和订单明细；
3. 调用 invoice-service 创建发票；
4. 返回订单号、总金额和发票号码。

> 当前项目使用 `X-User-Id` 模拟已登录用户，便于先学习微服务调用。正式项目应使用 Spring Security 和 JWT。
