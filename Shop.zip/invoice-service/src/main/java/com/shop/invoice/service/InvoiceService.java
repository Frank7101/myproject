package com.shop.invoice.service;

import com.shop.invoice.dto.CreateInvoiceRequest;
import com.shop.invoice.dto.InvoiceResponse;
import com.shop.invoice.entity.Invoice;
import com.shop.invoice.repository.InvoiceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Transactional
    public InvoiceResponse create(CreateInvoiceRequest request) {
        return invoiceRepository.findByOrderId(request.orderId())
                .map(this::toResponse)
                .orElseGet(() -> createNew(request));
    }

    public InvoiceResponse findByInvoiceNumber(String invoiceNumber) {
        return invoiceRepository.findByInvoiceNumber(invoiceNumber)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + invoiceNumber));
    }

    private InvoiceResponse createNew(CreateInvoiceRequest request) {
        Invoice invoice = new Invoice();
        invoice.setOrderId(request.orderId());
        invoice.setUserId(request.userId());
        invoice.setTotalAmount(request.totalAmount());
        invoice.setCreatedAt(LocalDateTime.now());

        invoice = invoiceRepository.save(invoice);

        String number = "INV-" +
                LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE) +
                "-" + String.format("%06d", invoice.getId());

        invoice.setInvoiceNumber(number);
        return toResponse(invoiceRepository.save(invoice));
    }

    private InvoiceResponse toResponse(Invoice invoice) {
        return new InvoiceResponse(
                invoice.getId(),
                invoice.getInvoiceNumber(),
                invoice.getOrderId(),
                invoice.getUserId(),
                invoice.getTotalAmount(),
                invoice.getCreatedAt()
        );
    }
}
