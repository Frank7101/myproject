package com.shop.invoice.controller;

import com.shop.invoice.dto.CreateInvoiceRequest;
import com.shop.invoice.dto.InvoiceResponse;
import com.shop.invoice.service.InvoiceService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    @PostMapping
    public InvoiceResponse create(@Valid @RequestBody CreateInvoiceRequest request) {
        return invoiceService.create(request);
    }

    @GetMapping("/{invoiceNumber}")
    public InvoiceResponse findByInvoiceNumber(@PathVariable String invoiceNumber) {
        return invoiceService.findByInvoiceNumber(invoiceNumber);
    }
}
