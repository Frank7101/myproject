package com.shop.invoice.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public record CreateInvoiceRequest(
        @NotNull Long orderId,
        @NotNull Long userId,
        @NotNull @Positive BigDecimal totalAmount
) {}
