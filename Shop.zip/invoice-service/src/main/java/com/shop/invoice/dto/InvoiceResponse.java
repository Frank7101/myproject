package com.shop.invoice.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record InvoiceResponse(
        Long invoiceId,
        String invoiceNumber,
        Long orderId,
        Long userId,
        BigDecimal totalAmount,
        LocalDateTime createdAt
) {}
