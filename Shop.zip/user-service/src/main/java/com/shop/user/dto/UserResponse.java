package com.shop.user.dto;

public record UserResponse(
        Long id,
        String username,
        String fullName
) {}
