package com.shop.order.service;

import com.shop.order.client.InvoiceClient;
import com.shop.order.client.ProductClient;
import com.shop.order.dto.*;
import com.shop.order.entity.OrderItem;
import com.shop.order.entity.ShopOrder;
import com.shop.order.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductClient productClient;
    private final InvoiceClient invoiceClient;

    public OrderService(
            OrderRepository orderRepository,
            ProductClient productClient,
            InvoiceClient invoiceClient
    ) {
        this.orderRepository = orderRepository;
        this.productClient = productClient;
        this.invoiceClient = invoiceClient;
    }

    @Transactional
    public OrderResponse createOrder(Long userId, CreateOrderRequest request) {
        ShopOrder order = new ShopOrder();
        order.setUserId(userId);
        order.setStatus("CREATED");
        order.setTotalAmount(BigDecimal.ZERO);
        order.setCreatedAt(LocalDateTime.now());

        BigDecimal total = BigDecimal.ZERO;

        for (OrderItemRequest itemRequest : request.items()) {
            ProductResponse product = productClient.getProduct(itemRequest.productId());

            if (product.stock() < itemRequest.quantity()) {
                throw new IllegalStateException("Insufficient stock for product: " + product.name());
            }

            BigDecimal subtotal = product.price()
                    .multiply(BigDecimal.valueOf(itemRequest.quantity()));

            OrderItem item = new OrderItem();
            item.setProductId(product.id());
            item.setProductName(product.name());
            item.setUnitPrice(product.price());
            item.setQuantity(itemRequest.quantity());
            item.setSubtotal(subtotal);

            order.addItem(item);
            total = total.add(subtotal);
        }

        order.setTotalAmount(total);
        order.setStatus("WAITING_FOR_INVOICE");
        order = orderRepository.save(order);

        for (OrderItemRequest itemRequest : request.items()) {
            productClient.reduceStock(itemRequest.productId(), itemRequest.quantity());
        }

        try {
            InvoiceResponse invoice = invoiceClient.createInvoice(
                    new CreateInvoiceRequest(order.getId(), userId, total)
            );
            order.setInvoiceNumber(invoice.invoiceNumber());
            order.setStatus("COMPLETED");
        } catch (RuntimeException exception) {
            order.setStatus("INVOICE_FAILED");
            orderRepository.save(order);
            throw exception;
        }

        return toResponse(orderRepository.save(order));
    }

    @Transactional(readOnly = true)
    public OrderResponse findById(Long id) {
        ShopOrder order = orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + id));
        order.getItems().size();
        return toResponse(order);
    }

    private OrderResponse toResponse(ShopOrder order) {
        List<OrderItemResponse> items = order.getItems().stream()
                .map(item -> new OrderItemResponse(
                        item.getProductId(),
                        item.getProductName(),
                        item.getUnitPrice(),
                        item.getQuantity(),
                        item.getSubtotal()
                ))
                .toList();

        return new OrderResponse(
                order.getId(),
                order.getUserId(),
                order.getTotalAmount(),
                order.getInvoiceNumber(),
                order.getStatus(),
                order.getCreatedAt(),
                items
        );
    }
}
