package com.shop.order.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record OrderResponse(
        Long orderId,
        Long userId,
        BigDecimal totalAmount,
        String invoiceNumber,
        String status,
        LocalDateTime createdAt,
        List<OrderItemResponse> items
) {}
