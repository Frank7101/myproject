package com.shop.order.client;

import com.shop.order.dto.CreateInvoiceRequest;
import com.shop.order.dto.InvoiceResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

@Component
public class InvoiceClient {

    private final RestClient restClient;

    public InvoiceClient(
            RestClient.Builder builder,
            @Value("${services.invoice.url}") String baseUrl
    ) {
        this.restClient = builder.baseUrl(baseUrl).build();
    }

    public InvoiceResponse createInvoice(CreateInvoiceRequest request) {
        try {
            return restClient.post()
                    .uri("/invoices")
                    .body(request)
                    .retrieve()
                    .body(InvoiceResponse.class);
        } catch (RestClientException exception) {
            throw new IllegalStateException("Failed to call invoice service: " + exception.getMessage(), exception);
        }
    }
}
