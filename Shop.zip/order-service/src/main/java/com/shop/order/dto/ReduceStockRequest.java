package com.shop.order.dto;

public record ReduceStockRequest(Integer quantity) {}
