package com.shop.order.dto;

import java.math.BigDecimal;

public record CreateInvoiceRequest(
        Long orderId,
        Long userId,
        BigDecimal totalAmount
) {}
