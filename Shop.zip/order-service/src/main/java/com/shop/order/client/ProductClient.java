package com.shop.order.client;

import com.shop.order.dto.ProductResponse;
import com.shop.order.dto.ReduceStockRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

@Component
public class ProductClient {

    private final RestClient restClient;

    public ProductClient(
            RestClient.Builder builder,
            @Value("${services.product.url}") String baseUrl
    ) {
        this.restClient = builder.baseUrl(baseUrl).build();
    }

    public ProductResponse getProduct(Long productId) {
        try {
            return restClient.get()
                    .uri("/products/{id}", productId)
                    .retrieve()
                    .body(ProductResponse.class);
        } catch (RestClientException exception) {
            throw new IllegalStateException("Failed to query product service: " + exception.getMessage(), exception);
        }
    }

    public ProductResponse reduceStock(Long productId, Integer quantity) {
        try {
            return restClient.post()
                    .uri("/products/{id}/reduce-stock", productId)
                    .body(new ReduceStockRequest(quantity))
                    .retrieve()
                    .body(ProductResponse.class);
        } catch (RestClientException exception) {
            throw new IllegalStateException("Failed to reduce product stock: " + exception.getMessage(), exception);
        }
    }
}
